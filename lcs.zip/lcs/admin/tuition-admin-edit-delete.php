

<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
	  <meta name="keywords" content="web design, affordable web design, professional web design">
  	<meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/style-tuition.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
           <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
      <div class="container">
       
           <div class = "tuition-group">
              <div>
                <h2> Manage Tuition Fees</h2>
                <p> Welcome to tution summary page. Select the correct level to see how much is the tution fee for the currect school year. </p>
                
              </div>
              <div>
              <table>
                <tr>

                  <th colspan = 2>
                    <p><b>ASSESMENT OF FEES</b></p>
                  </th>
                </tr>
                <?php

                  $msg ="";

                  include_once '../resource/db.php';
                  include_once '../resource/session.php';
                  
                  

                  if (isset($_POST['update'])){
                   

                    $con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');   
                    $gradeCode = $con->real_escape_string($_POST['hidden']);
                    $_SESSION['gradeCode'] = $gradeCode;


                    $sql = $con-> query("SELECT * FROM tuition WHERE LOWER(gradeCode)= '$_SESSION[gradeCode]'");

                    while($row = mysqli_fetch_array($sql))
                        {
                        echo "<form method=post action=tuition-admin-update.php>";
                        echo "<tr>";
                        echo "<td>Grade Code</td>";
                        echo "<td>
                              <input type=text name=gradeCode value='".ucfirst($row['gradeCode'])."' ></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Tution Fee</td>";
                        echo "<td> 
                              <input type=text name=tuitionFee value='".$row['tuitionFee']."'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Miscellaneous Fee</td>";
                        echo "<td>
                              <input type=text name=miscellaneousFee value='".$row['miscellaneousFee']."'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Books Fee</td>";
                        echo "<td>
                              <input type=text name=booksFee value='". $row['booksFee']. "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Registration Fee</td>";
                        echo "<td>
                              <input type=text name=registrationFee value='" . $row['registrationFee'] . "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Other Instruction Fee</td>";
                        echo "<td>
                              <input type=text name=otherInstructionalFee value='". $row['otherInstructionalFee'] . "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Uniform Fee</td>";
                        echo "<td>
                              <input type=text name=uniformsFee value='" . $row['uniformsFee'] . "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>PTA Donation Fee</td>";
                        echo "<td>
                              <input type=text name=ptaDonationFee value='". $row['ptaDonationFee'] . "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Tution Fee</td>";
                        echo "<td>
                              <input type=text name=otherFee value='". $row['otherFee'] . "'></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td colspan=2>
                              <input type=submit name=update_record value=Update Record></td>";
                        echo "</tr>";

                        echo "</form>";
                        
                        
                          }
                    }
                    if (isset($_POST['delete'])){
                        $con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');    
                        $gradeCode = $con->real_escape_string($_POST['hidden']);
                        $_SESSION['gradeCode'] = $gradeCode;
                        
                        $sql = $con-> query("DELETE FROM tuition WHERE LOWER(gradeCode)='$gradeCode'");
                        header("Location: tuition-admin-view.php");
                    }
                  ?>


              </table>
              </div>

            </div>
    
      </div>
      
      
      

    </section>
  
    

    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>\
  </body>
</html>

