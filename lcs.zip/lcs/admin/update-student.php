<?php


include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}


$enrolleeExamDate = $_POST['enrolleeExamDate'];
$enrolleeExamTime = $_POST['Hour'].":".$_POST['minutes']." ".$_POST['timeZone'];
$permStudentNumber = $_POST['studentID'];
$studentID = $_POST['studentID'];
$enrolleeCode = "LCS";
$enrolledByEmailAddress ="";
$enrolledBy = "";
$enrolleeFirstName = "";
$enrolleeLastName = "";
$gradeLevel ="";
$enrolleeHouseNo = "";
$enrolleeStreet = "";
$enrolleeBarangay = "";
$enrolleeMunicipality = "";
$enrolleeProvince = "";
$enrolleeCountry = "";
$enrolleeZipCode = "";
$booksFee ="";
$miscellaneousFee = "";
$otherFee = "";
$otherInstructionalFee = "";
$ptaDonationFee = "";
$registrationFee = "";
$tuitionFee = "";
$uniformsFee = "";
$totalFees ="";


$con2 = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');
$sql2 = $con2->query("SELECT enrolledByEmailAddress, enrolledBy, enrolleeFirstName, enrolleeLastName, gradeLevel, enrolleeHouseNo, enrolleeStreet, enrolleeBarangay, enrolleeMunicipality, enrolleeProvince, enrolleeCountry, enrolleeZipCode FROM enrollee WHERE studentReferenceNo = '$permStudentNumber'");
      while($row2 = mysqli_fetch_array($sql2)){            
      $enrolledByEmailAddress = $row2['enrolledByEmailAddress'];
      $enrolledBy = $row2['enrolledBy'];
      $enrolleeFirstName = $row2['enrolleeFirstName'];
      $enrolleeLastName = $row2['enrolleeLastName'];
      $gradeLevel = $row2['gradeLevel'];
      $enrolleeHouseNo = $row2['enrolleeHouseNo'];
      $enrolleeStreet = $row2['enrolleeStreet'];
      $enrolleeBarangay = $row2['enrolleeBarangay'];
      $enrolleeMunicipality = $row2['enrolleeMunicipality'];
      $enrolleeProvince = $row2['enrolleeProvince'];
      $enrolleeCountry = $row2['enrolleeCountry'];
      $enrolleeZipCode = $row2['enrolleeZipCode'];

}

$gradeLevel2 = strtolower($_POST['gradeLevel']);
//$con3 = new mysqli('localhost', 'root', '', 'lcs');
$sql3 = $con2->query("SELECT * FROM tuition WHERE LOWER(gradeCode)='$gradeLevel2'");
while($row3 = mysqli_fetch_array($sql3)){

$booksFee = $row3['booksFee'];
$miscellaneousFee = $row3['miscellaneousFee'];
$otherFee = $row3['otherFee'];
$otherInstructionalFee = $row3['otherInstructionalFee'];
$ptaDonationFee = $row3['ptaDonationFee'];
$registrationFee = $row3['registrationFee'];
$tuitionFee = $row3['tuitionFee'];
$uniformsFee = $row3['uniformsFee'];

$totalFees = $booksFee + $miscellaneousFee + $otherFee + $otherInstructionalFee + $ptaDonationFee + $registrationFee + $tuitionFee + $uniformsFee;

}


if(isset($_POST['updateStudentRecord'])){
                          include_once '../resource/db.php';
                        
                          if ($_POST['statusChange'] == "Enrolled" && $_POST['permstudentID'] != ""){

                                  $sql = "UPDATE enrollee SET enrollmentStatus = :enrollmentStatus, 
                                  studentID = :permstudentID,
                                  enrolleeCode = :enrolleeCode
                                  WHERE studentReferenceNo = :studentID";

                                        $stmt = $dbconn->prepare($sql);                                  
                                        $stmt->bindParam(':enrollmentStatus', $_POST['statusChange']);       
                                        $stmt->bindParam(':permstudentID', $_POST['permstudentID']);    
                                        $stmt->bindParam(':enrolleeCode', $enrolleeCode);    
                                        $stmt->bindParam(':studentID', $studentID); 
                                       
                                        if ($stmt->execute()){
                                           echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';

                                            include_once "../PHPMailer/PHPMailer.php";
                                            include_once "../PHPMailer/Exception.php";
                                            include_once "../PHPMailer/SMTP.php";

                                            $mail =  new PHPMailer\PHPMailer\PHPMailer();
                                            $mail->isSMTP();
                                            $mail->SMTPDebug = 0;
                                            $mail->Host = "smtp.gmail.com";
                                            $mail->Port = 587;
                                            $mail->SMTPSecure = 'tls';
                                            $mail->SMTPAuth = true;
                                            $mail->Username = 'mptercero@up.edu.ph';
                                            $mail->Password = 'seudriiwmozxuzdu';
                                            $mail->setFrom($mail->Username);
                                            $mail->addAddress($enrolledByEmailAddress);
                                            $mail->Subject = 'Enrollment Status Change: '.$_POST['statusChange'];
                                            $message = "<p><b>Dear ".$enrolleeFirstName."</b>,</p>

                                            <p>Congratulations! You are now enrolled.</p>

                                            <p>Following are the information of your enrollment:</p>

                                            <p><b>Name: </b>".$enrolleeFirstName." ".$enrolleeLastName."<br>
                                            <b>Student Number: </b>".$_POST['permstudentID']."<br>
                                            <b>Grade Level: </b>".$gradeLevel."<br>
                                            <b>Address: </b>".$enrolleeHouseNo.", ".$enrolleeStreet.", ".$enrolleeBarangay.", ".$enrolleeMunicipality.", ".$enrolleeProvince.", ".$enrolleeCountry." ".$enrolleeZipCode."<br> </p>



                                            <p>School Admin</p>";

                                            $mail->msgHTML($message);
                                            $mail->AltBody = strip_tags($message);
                                                   
                                            if ($mail->send()){
                                                echo "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>Enrollment Processing Successful! An email has been sent to the enrollee's email address as a receipt! <a href=process-enrollment-new.php>Click here to process more enrollment application. </a> </p>";
                                                  
                                              }
                                            else{
                                                $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
                                                }





                                        }else{
                                            echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                                        }




                            }
                          if ($_POST['statusChange'] == "For Interview" || $_POST['statusChange'] == "For Examination"){

                                  $sql = "UPDATE enrollee SET enrollmentStatus = :enrollmentStatus, 
                                  enrolleeExamDate = :enrolleeExamDate,
                                  enrolleeExamTime = :enrolleeExamTime
                                  WHERE studentID = :studentID";

                                        $stmt = $dbconn->prepare($sql);                                  
                                        $stmt->bindParam(':enrollmentStatus', $_POST['statusChange']);       
                                        $stmt->bindParam(':enrolleeExamDate', $enrolleeExamDate); 
                                        $stmt->bindParam(':enrolleeExamTime', $enrolleeExamTime);  
                                        $stmt->bindParam(':studentID', $_POST['studentID']);    
                                       
                                        if ($stmt->execute()){
                                           echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';



                                           include_once "../PHPMailer/PHPMailer.php";
                                            include_once "../PHPMailer/Exception.php";
                                            include_once "../PHPMailer/SMTP.php";

                       

                                            $mail =  new PHPMailer\PHPMailer\PHPMailer();
                                            $mail->isSMTP();
                                            $mail->SMTPDebug = 0;
                                            $mail->Host = "smtp.gmail.com";
                                            $mail->Port = 587;
                                            $mail->SMTPSecure = 'tls';
                                            $mail->SMTPAuth = true;
                                            $mail->Username = 'mptercero@up.edu.ph';
                                            $mail->Password = 'seudriiwmozxuzdu';
                                            $mail->setFrom($mail->Username);
                                            $mail->addAddress($enrolledByEmailAddress);
                                            $mail->Subject = 'Enrollment Status Change: '.$_POST['statusChange'];
                                            $message = "<p><b>Dear ".$enrolleeFirstName."</b>,</p>

                                            <p>Congratulations! You are invited ".$_POST['statusChange'].".</p>

                                            <p><b>Schedule ".$_POST['statusChange'].": ".$enrolleeExamDate.", ".$enrolleeExamTime."</b></p>

                                            <p>Following are the information of your enrollment:</p>

                                            <p><b>Name: </b>".$enrolleeFirstName." ".$enrolleeLastName."<br>
                                            <b>Temporary Student Number: </b>".$studentID."<br>
                                            <b>Grade Level: </b>".$gradeLevel."<br>
                                            <b>Address: </b>".$enrolleeHouseNo.", ".$enrolleeStreet.", ".$enrolleeBarangay.", ".$enrolleeMunicipality.", ".$enrolleeProvince.", ".$enrolleeCountry." ".$enrolleeZipCode."<br> </p>



                                            <p>School Admin</p>";

                                            $mail->msgHTML($message);
                                            $mail->AltBody = strip_tags($message);
                                                   
                                            if ($mail->send()){
                                                 echo "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>Enrollment Processing Successful! An email has been sent to the enrollee's email address as a receipt! <a href=process-enrollment-new.php>Click here to process more enrollment application. </a> </p>";
                                                  
                                              }
                                            else{
                                                $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
                                                }


                                        }else{
                                            echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                                        }

                          }
                          if ($_POST['statusChange'] == "Pending for Approval"){

                                  $sql = "UPDATE enrollee SET enrollmentStatus = :enrollmentStatus
                                  WHERE studentID = :studentID";

                                        $stmt = $dbconn->prepare($sql);                                  
                                        $stmt->bindParam(':enrollmentStatus', $_POST['statusChange']); 
                                        $stmt->bindParam(':studentID', $_POST['studentID']); 
                                       
                                        if ($stmt->execute()){
                                           echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';


                                           include_once "../PHPMailer/PHPMailer.php";
                                            include_once "../PHPMailer/Exception.php";
                                            include_once "../PHPMailer/SMTP.php";

                       

                                            $mail =  new PHPMailer\PHPMailer\PHPMailer();
                                            $mail->isSMTP();
                                            $mail->SMTPDebug = 0;
                                            $mail->Host = "smtp.gmail.com";
                                            $mail->Port = 587;
                                            $mail->SMTPSecure = 'tls';
                                            $mail->SMTPAuth = true;
                                            $mail->Username = 'mptercero@up.edu.ph';
                                            $mail->Password = 'seudriiwmozxuzdu';
                                            $mail->setFrom($mail->Username);
                                            $mail->addAddress($enrolledByEmailAddress);
                                            $mail->Subject = 'Enrollment Status Change: '.$_POST['statusChange'];
                                            $message = "<p><b>Dear ".$enrolleeFirstName."</b>,</p>

                                            <p>Update: ".$_POST['statusChange']."</p>

                                            <p>The status means that there a need for a further approval from the admin related to your interest enrolling/re-enrolling. Once approval is done, we will proceed the normal enrollment process.</p>

                                            <p>Following are the information of your enrollment:</p>

                                            <p><b>Name: </b>".$enrolleeFirstName." ".$enrolleeLastName."<br>
                                            <b>Temporary Student Number: </b>".$studentID."<br>
                                            <b>Grade Level: </b>".$gradeLevel."<br>
                                            <b>Address: </b>".$enrolleeHouseNo.", ".$enrolleeStreet.", ".$enrolleeBarangay.", ".$enrolleeMunicipality.", ".$enrolleeProvince.", ".$enrolleeCountry." ".$enrolleeZipCode."<br> </p>



                                            <p>School Admin</p>";

                                            $mail->msgHTML($message);
                                            $mail->AltBody = strip_tags($message);
                                                   
                                            if ($mail->send()){
                                                 echo "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>Enrollment Processing Successful! An email has been sent to the enrollee's email address as a receipt! <a href=process-enrollment-new.php>Click here to process more enrollment application. </a> </p>";
                                                  
                                              }
                                            else{
                                                $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
                                                }
                                        }else{
                                            echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                                        }

                          }
                          if ($_POST['statusChange'] == "For Payment"){

                                  $sql = "UPDATE enrollee SET enrollmentStatus = :enrollmentStatus
                                  WHERE studentID = :studentID";

                                        $stmt = $dbconn->prepare($sql);                                  
                                        $stmt->bindParam(':enrollmentStatus', $_POST['statusChange']); 
                                        $stmt->bindParam(':studentID', $_POST['studentID']); 
                                       
                                        if ($stmt->execute()){
                                           echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';


                                           include_once "../PHPMailer/PHPMailer.php";
                                            include_once "../PHPMailer/Exception.php";
                                            include_once "../PHPMailer/SMTP.php";

                       

                                            $mail =  new PHPMailer\PHPMailer\PHPMailer();
                                            $mail->isSMTP();
                                            $mail->SMTPDebug = 0;
                                            $mail->Host = "smtp.gmail.com";
                                            $mail->Port = 587;
                                            $mail->SMTPSecure = 'tls';
                                            $mail->SMTPAuth = true;
                                            $mail->Username = 'mptercero@up.edu.ph';
                                            $mail->Password = 'seudriiwmozxuzdu';
                                            $mail->setFrom($mail->Username);
                                            $mail->addAddress($enrolledByEmailAddress);
                                            $mail->Subject = 'Enrollment Status Change: '.$_POST['statusChange'];
                                            $message = "<p><b>Dear ".$enrolleeFirstName."</b>,</p>

                                            <p>Update: ".$_POST['statusChange']."</p>

                                            <p>Following are the information of your enrollment:</p>

                                            <p><b>Name: </b>".$enrolleeFirstName." ".$enrolleeLastName."<br>
                                            <b>Temporary Student Number: </b>".$studentID."<br>
                                            <b>Grade Level: </b>".$gradeLevel."<br>
                                            <b>Address: </b>".$enrolleeHouseNo.", ".$enrolleeStreet.", ".$enrolleeBarangay.", ".$enrolleeMunicipality.", ".$enrolleeProvince.", ".$enrolleeCountry." ".$enrolleeZipCode."<br> </p>

                                            <p>You will need to settle the payment in the school's accounting office. Below is the tuition fee assesseement information. </p>

                                            <p><i>Note: You may fully pay/partially pay the tuition fee, ask for an advice from our accounting office assistant.</i></p>

                                            <p> ASSESSMENT FEES </p>
                                                <b>Books Fee </b>: PHP ". $booksFee.".00 <br>
                                                <b>Miscellaneous Fee </b>: PHP ".$miscellaneousFee.".00 <br>
                                                <b>Other Fees </b>: PHP ".$otherFee.".00 <br>
                                                <b>Other Instrutional Fees </b>: PHP ".$otherInstructionalFee.".00 <br>
                                                <b>PTA Donation Fee </b>: PHP ".$ptaDonationFee.".00 <br>
                                                <b>Registration Fee </b>: PHP ".$registrationFee.".00 <br>
                                                <b>Tuition Fee </b>: PHP ".$tuitionFee.".00 <br>
                                                <b>Uniform Fee </b>: PHP ".$uniformsFee.".00 <br>

                                              <p><b>TOTAL FEES </b>: PHP ".$totalFees.".00 </p>


                                            <p>School Admin</p>";

                                            $mail->msgHTML($message);
                                            $mail->AltBody = strip_tags($message);
                                                   
                                            if ($mail->send()){
                                                 echo "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>Enrollment Processing Successful! An email has been sent to the enrollee's email address as a receipt! <a href=process-enrollment-new.php>Click here to process more enrollment application. </a> </p>";                                                  
                                              }
                                            else{
                                                $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
                                                }
                                        }else{
                                            echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                                        }

                          }

  }

?>
