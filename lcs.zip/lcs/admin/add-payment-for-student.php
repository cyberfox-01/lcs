<?php

include_once '../resource/session.php';
include_once '../resource/db.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}
$enrolledByEmailAddress = $_POST['enrolledByEmailAddress'];

if (isset($_POST['AddPayment'])){

	$studentID = $_SESSION['studentID'];
	$descriptions = $_POST['comment'];
	$paymentMadeWhen = date("Y-m-d h:i:sa");
	$amountPaid = $_POST['amountPaid'];
	$paymentProcessedBy = $_SESSION['username'];

  $stmt2 = $dbconn->prepare('INSERT INTO studentpayments (studentID, descriptions, paymentMadeWhen, amountPaid, paymentProcessedBy) VALUES (:studentID, :descriptions, :paymentMadeWhen, :amountPaid, :paymentProcessedBy);');

  $stmt2->bindValue(':studentID', $studentID);
  $stmt2->bindValue(':descriptions', $descriptions);
  $stmt2->bindValue(':paymentMadeWhen', $paymentMadeWhen);
  $stmt2->bindValue(':amountPaid', $amountPaid);
  $stmt2->bindValue(':paymentProcessedBy', $paymentProcessedBy);
 if ($stmt2->execute()){
       echo '<script type = "text/javascript"> alert("Record added successfully");</script>';

        include_once "../PHPMailer/PHPMailer.php";
        include_once "../PHPMailer/Exception.php";
        include_once "../PHPMailer/SMTP.php";

        $mail =  new PHPMailer\PHPMailer\PHPMailer();
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587;
        $mail->SMTPSecure = 'tls';
        $mail->SMTPAuth = true;
        $mail->Username = 'mptercero@up.edu.ph';
        $mail->Password = 'seudriiwmozxuzdu';
        $mail->setFrom($mail->Username);
        $mail->addAddress($enrolledByEmailAddress);
        $mail->Subject = 'Payment Successful';
        $message = "<p><b>Dear ".$studentID."</b>,</p>

        <p> We have successfully processed and updated your payment. Please see information below:</p>

        <p>PAYMENT DETAILS</p>
        <p>TOTAL AMOUNT PAID: PHP ".$amountPaid.".00 <p>

         <p>PAID FOR: <br>".$descriptions."<p>


        <p>School Admin</p>";

        $mail->msgHTML($message);
        $mail->AltBody = strip_tags($message);
               
        if ($mail->send()){
            echo "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>Payment posting went successful! An email has been sent to the enrollee's email address as a receipt! <a href=add-student-payment.php>Click here to post another payment.</a></p>";
              
          }
        else{
            $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 700px; margin-left: 700px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
            }





    }else{
        echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
    }
}



?>
