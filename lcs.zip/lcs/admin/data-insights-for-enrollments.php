

<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}


$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');   
        $sql = $con-> query("SELECT * FROM enrollee");


        $sqlNew = $con->query("SELECT COUNT(enrollmentStatus) as countNew FROM enrollee WHERE enrollmentStatus = 'New';");
        while ($rowNew = $sqlNew->fetch_assoc())
        $new = (integer)$rowNew['countNew'];


        $sqlEnrolled = $con->query("SELECT COUNT(enrollmentStatus) as countEnrolled FROM enrollee WHERE enrollmentStatus = 'Enrolled';");
        while ($rowEnrolled = $sqlEnrolled->fetch_assoc())
        $enrolled = (integer)$rowEnrolled['countEnrolled'];

        $sqlPending = $con->query("SELECT COUNT(enrollmentStatus) as countPending FROM enrollee WHERE enrollmentStatus = 'Pending for Approval';");
        while ($rowPending = $sqlPending->fetch_assoc())
        $pending = (integer)$rowPending['countPending'];


        $sqlInterview = $con->query("SELECT COUNT(enrollmentStatus) as countInterview FROM enrollee WHERE enrollmentStatus = 'For Interview';");
        while ($rowInterview = $sqlInterview->fetch_assoc())
        $interview = (integer)$rowInterview['countInterview'];


        $sqlExamination = $con->query("SELECT COUNT(enrollmentStatus) as countExamination FROM enrollee WHERE enrollmentStatus = 'For Examination';");
        while ($rowExamination = $sqlExamination->fetch_assoc())
        $examination = (integer)$rowExamination['countExamination'];

        $sqlPayment = $con->query("SELECT COUNT(enrollmentStatus) as countPayment FROM enrollee WHERE enrollmentStatus = 'For Payment';");
        while ($rowPayment = $sqlPayment->fetch_assoc())
        $payment = (integer)$rowPayment['countPayment'];


        $sqlkinderone = $con->query("SELECT COUNT(gradeLevel) as kinderone FROM enrollee WHERE gradeLevel = 'Kinder I';");
        while ($rowkinderone = $sqlkinderone->fetch_assoc())
        $kinderone = (integer)$rowkinderone['kinderone'];

        $sqlkindertwo = $con->query("SELECT COUNT(gradeLevel) as kindertwo FROM enrollee WHERE gradeLevel = 'Kinder II';");
        while ($rowkindertwo = $sqlkindertwo->fetch_assoc())
        $kindertwo = (integer)$rowkindertwo['kindertwo'];

        $sqlgradeone = $con->query("SELECT COUNT(gradeLevel) as gradeone FROM enrollee WHERE gradeLevel = 'Grade 1';");
        while ($rowgradeone = $sqlgradeone->fetch_assoc())
        $gradeone = (integer)$rowgradeone['gradeone'];


        $sqlgradetwo = $con->query("SELECT COUNT(gradeLevel) as gradetwo FROM enrollee WHERE gradeLevel = 'Grade 2';");
        while ($rowgradetwo = $sqlgradetwo->fetch_assoc())
        $gradetwo = (integer)$rowgradetwo['gradetwo'];


        $sqlgradethree = $con->query("SELECT COUNT(gradeLevel) as gradethree FROM enrollee WHERE gradeLevel = 'Grade 3';");
        while ($rowgradethree = $sqlgradethree->fetch_assoc())
        $gradethree = (integer)$rowgradethree['gradethree'];


        $sqlgradefour = $con->query("SELECT COUNT(gradeLevel) as gradefour FROM enrollee WHERE gradeLevel = 'Grade 4';");
        while ($rowgradefour = $sqlgradefour->fetch_assoc())
        $gradefour = (integer)$rowgradefour['gradefour'];

         $sqlgradefive = $con->query("SELECT COUNT(gradeLevel) as gradefive FROM enrollee WHERE gradeLevel = 'Grade 5';");
        while ($rowgradefive = $sqlgradefive->fetch_assoc())
        $gradefive = (integer)$rowgradefive['gradefive'];

        $sqlgradesix = $con->query("SELECT COUNT(gradeLevel) as gradesix FROM enrollee WHERE gradeLevel = 'Grade 6';");
        while ($rowgradesix = $sqlgradesix->fetch_assoc())
        $gradesix = (integer)$rowgradesix['gradesix'];

        $sqlgradeseven = $con->query("SELECT COUNT(gradeLevel) as gradeseven FROM enrollee WHERE gradeLevel = 'Grade 7';");
        while ($rowgradeseven = $sqlgradeseven->fetch_assoc())
        $gradeseven = (integer)$rowgradeseven['gradeseven'];

        $sqlgradeeight = $con->query("SELECT COUNT(gradeLevel) as gradeeight FROM enrollee WHERE gradeLevel = 'Grade 8';");
        while ($rowgradeeight = $sqlgradeeight->fetch_assoc())
        $gradeeight = (integer)$rowgradeeight['gradeeight'];

        $sqlgradenine = $con->query("SELECT COUNT(gradeLevel) as gradenine FROM enrollee WHERE gradeLevel = 'Grade 9';");
        while ($rowgradenine = $sqlgradenine->fetch_assoc())
        $gradenine = (integer)$rowgradenine['gradenine'];

        $sqlgradeten = $con->query("SELECT COUNT(gradeLevel) as gradeten FROM enrollee WHERE gradeLevel = 'Grade 10';");
        while ($rowgradeten = $sqlgradeten->fetch_assoc())
        $gradeten = (integer)$rowgradeten['gradeten'];

        $sqlgradeeleven = $con->query("SELECT COUNT(gradeLevel) as gradeeleven FROM enrollee WHERE gradeLevel = 'Grade 11';");
        while ($rowgradeeleven = $sqlgradeeleven->fetch_assoc())
        $gradeeleven = (integer)$rowgradeeleven['gradeeleven'];

        $sqlgradetwelve = $con->query("SELECT COUNT(gradeLevel) as gradetwelve FROM enrollee WHERE gradeLevel = 'Grade 12';");
        while ($rowgradetwelve = $sqlgradetwelve->fetch_assoc())
        $gradetwelve = (integer)$rowgradetwelve['gradetwelve'];


        $sqltotalstudents = $con->query("SELECT COUNT(enrolleeCode) as totalstudents FROM enrollee WHERE enrolleeCode = 'LCS';");
        while ($rowtotalstudents = $sqltotalstudents->fetch_assoc())
        $totalstudents = (integer)$rowtotalstudents['totalstudents'];

?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
	  <meta name="keywords" content="LCS Online Enrollment System">
  	<meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="../css/style-admin.css">
  </head>
  <body>
    <header>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([

        ["Status", "Count", { role: "style" } ],

        ["New", <?php echo $new; ?>, "#04197A"],
        ["Enrolled", <?php  echo $enrolled;  ?>, "#04197A"],
        ["Pending Approval", <?php echo $pending;  ?>, "color: #04197A"],
        ["For Interview", <?php echo $interview;  ?>, "color: #04197A"],
        ["For Examination", <?php echo $examination; ?>, "color: #04197A"],
        ["For Payment", <?php echo $examination; ?>, "color: #04197A"]
        

      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Summary Count of Enrollment Per Status",
        width: 800,
        height: 300,
        bar: {groupWidth: "70%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  }
  </script>



  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([

        ["Grade Level", "Count", { role: "style" } ],


        ["K-I", <?php echo $kinderone; ?>, "#04197A"],
        ["K-II", <?php  echo $kindertwo;  ?>, "#04197A"],
        ["G-I", <?php echo $gradeone; ?>, "#04197A"],
        ["G-II", <?php  echo $gradetwo;  ?>, "#04197A"],
        ["G-III", <?php echo $gradethree;  ?>, "color: #04197A"],
        ["G-IV", <?php echo $gradefour;  ?>, "color: #04197A"],
        ["G-V", <?php echo $gradefive; ?>, "color: #04197A"],
        ["G-VI", <?php echo $gradesix; ?>, "color: #04197A"],
        ["G-VII", <?php echo $gradeseven; ?>, "color: #04197A"],
        ["G-VIII", <?php echo $gradeeight; ?>, "color: #04197A"],
        ["G-IX", <?php echo $gradenine; ?>, "color: #04197A"],
        ["G-X", <?php echo $gradeten; ?>, "color: #04197A"],
        ["G-XI", <?php echo $gradeeleven; ?>, "color: #04197A"],
        ["G-XII", <?php echo $gradetwelve; ?>, "color: #04197A"]
        
        

      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Summary Count of Enrollees Per Grade Level",
        width: 800,
        height: 300,
        bar: {groupWidth: "70%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_grade"));
      chart.draw(view, options);
  }
  </script>

 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([

        ["Year", "No. of Students", { role: "style" } ],


        ['2018', 1000, "color: #04197A"],
          ['2019',<?php echo $totalstudents; ?>, "color: #04197A"],
          ['2020', 0, "color: #04197A"],
          ['2021', 0, "color: #04197A"],
          ['2022', 0, "color: #04197A"],
          ['2023', 0, "color: #04197A"],
          ['2024', 0, "color: #04197A"]
        
        

      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Summary of Total Number Students Enrolled Per Year",
        width: 800,
        height: 300,
        bar: {groupWidth: "70%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_student"));
      chart.draw(view, options);
  }
  </script>




      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
           <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>
    <section id="showcase">
      <div class="container">
        <h1><span class = "highlight">LCS</span> Enrollment Data Insights</h1>

        <h3> Howdy, <br> Below is our data insight for today! </h3>

        <p> We have a total of <b><u><?php echo $new; ?></u></b> enrollee/s new today! <br> 
        So far, we have a total number of <b><u><?php echo $enrolled; ?></u></b> students who are officially enrolled today! <br> 
        Currently, we have a total number of <b><u><?php echo $interview; ?></u></b> applicant scheduled of for interview! <br> 
         Currently, we have a total number of <b><u><?php echo $examination; ?> </u></b> applicant scheduled of for examination! <br> 
        So far, we have a total of <b><u><?php echo $pending; ?> </u></b> student/s who is/are pending for approval! <br>
        You may want to follow-up these total of <b><u><?php echo $payment; ?> </u></b> student/s who is/are for payment status! <br>
      </p>
       
       

        
      </div>
      
        <section id="boxes">
          <div class="container" align="center">
            <div id="columnchart_values" style="width: 900px; height: 300px;"></div>
          </div>
        </section>
        <section id="boxes">

        <section id="boxes">
          <div class="container" align="center">
            <div id="columnchart_grade" style="width: 900px; height: 300px;"></div>
          </div>
        </section>

          <section id="boxes">
          <div class="container" align="center">
            <div id="columnchart_student" style="width: 1000px; height: 600px;"></div>
          </div>
        </section>
       
    
      

    </section>



    


    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
