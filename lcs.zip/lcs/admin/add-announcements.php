<?php
$msg = "";

include_once '../resource/session.php';
include_once '../resource/db.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}

$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');



if (isset($_POST['postAnnoucement'])){

	$postedBy = $_SESSION['username'];
	$announcement = $_POST['comment'];
	$datePosted = date("Y-m-d h:i:sa");
	$announcementTitle = $_POST['title'];

  $stmt2 = $dbconn->prepare('INSERT INTO announcement (postedBy, datePosted, announcement, announcementTitle) VALUES (:postedBy, :datePosted, :announcement, :announcementTitle);');

  $stmt2->bindValue(':postedBy', $postedBy);
  $stmt2->bindValue(':datePosted', $datePosted);
  $stmt2->bindValue(':announcement', $announcement);
  $stmt2->bindValue(':announcementTitle', $announcementTitle);

 if ($stmt2->execute()){
       echo '<script type = "text/javascript"> alert("Announcement has added successfully");</script>';

       if (isset($_POST['sendtoUsers'])){

       				
       				$sql = $con-> query("SELECT name, email FROM users;");
       				while($row = mysqli_fetch_array($sql))

                        {
                        	$name = $row['name'];
                        	$email = $row['email'];

                        					include_once "../PHPMailer/PHPMailer.php";
									        include_once "../PHPMailer/Exception.php";
									        include_once "../PHPMailer/SMTP.php";

									        $mail =  new PHPMailer\PHPMailer\PHPMailer();
									        $mail->isSMTP();
									        $mail->SMTPDebug = 0;
									        $mail->Host = "smtp.gmail.com";
									        $mail->Port = 587;
									        $mail->SMTPSecure = 'tls';
									        $mail->SMTPAuth = true;
									        $mail->Username = 'mptercero@up.edu.ph';
									        $mail->Password = 'seudriiwmozxuzdu';
									        $mail->setFrom($mail->Username);
									        $mail->addAddress($email);
									        $mail->Subject = 'LCS posted an annoucement.';
									        $message = "<p><b>Dear ".$name."</b>,</p>

									        <p>LCS Posted an annoucement:</p>

									        <p><b>".$announcementTitle."</b></p>
									        <p><i>".$announcement.".<i><p>

									        <p>School Admin</p>";

									        $mail->msgHTML($message);
									        $mail->AltBody = strip_tags($message);
									               
									        if ($mail->send()){
									            $msg = "<p style = 'padding: 20px; color: green; background-color: white; margin-right: 300px; margin-left: 300px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An email has been sent to the user's email addresses!</p>";
									              
									          }
									        else{
									            $msg = "<p style = 'padding: 20px; color: red; background-color: white; margin-right: 700px; margin-left: 700px; border-radius: 5px;  background: rgba(255, 255, 255, 0.6); '>An error has occured!</p>";
									            }



						       }





                        }




			       

    }else{
        echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
    }
}


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
    <meta name="keywords" content="web design, affordable web design, professional web design">
    <meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/announce-style-form.css">
  </head>
  <body>  


    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
         <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>
    <div style = "min-height: 100px; margin-left: 40px; margin-right: 40px; border-radius: 20px;">
   
          <form class="" method ="post" action = "add-announcements.php">
            <table style="width:100%">
              <tr>
                <td>
                  <h1> Add Announcement</h1>
                </td>
              </tr>
            	<tr>

                <td colspan = 2>
                  <div class = "" align = "left" style = "margin-left: 100px">
                  	<p><?php echo $msg; ?></p>                  	
                  	<label for="fname"><b>Title:</b></label><br>
                  	<input id = "" style = 'height: 30px; border-radius: 5px 10px; width: 965px;'  type="text" name="title" /><br><br>
                    <label for="fname"><b>Create Announcement:</b></label><br>
                    <textarea id="comment" name="comment" style = 'border-radius: 5px 10px; font-family:"Century Gothic", Century Gothic, serif; font-size: 12px;' rows="9" cols="160"></textarea><br>
                    Send to users <input id = ""  type="checkbox" name="sendtoUsers" value="" onclick=""/>

                     <div class = "" align = "right" style = "margin-bottom: 30px; margin-right: 100px;">
                        <input type="submit" name = "postAnnoucement" value = "Post Annoucement">
                    </div>


                  </div>
                </td>


                
              </tr>
              
           

            </table>
            
             
          </form>
        
    
      </div>

 
          <form class="" method ="post" action = "add-announcements.php">
    
              
            <div style =  "margin-left: 150px; margin-right: 150px; margin-top: 40px; margin-bottom: 60px; text-align:justify">
             
            <h1 style="color:#051055; font-size: 40px; text-shadow: 1px 1px #FB6B0D; text-align: center;">Announcements</h1>

              
                
                
              <?php
                
              $sql2 = $con-> query("SELECT * FROM announcement ORDER BY datePosted DESC LIMIT 5;");

              while($row2 = mysqli_fetch_array($sql2))

                        {
                          $postedBy2 = $row2['postedBy'];
                          $announcement2 = $row2['announcement'];
                          $datePosted2 = $row2['datePosted'];
                          $announcementTitle2 = $row2['announcementTitle'];
                          $id = $row2['id'];


              echo "<tr>";
              
              echo "<b><a href=#>".$announcementTitle2."</a></b><br>";
              echo "<p style='color: green; font-size: 11px;'><a href=http://localhost/lcs/includes/deleteannoucement.php?id=".$id.">Delete</a> | <a href=http://localhost/lcs/admin/updateannouncement.php?id=".$id."> Update</a>   <br>Posted by: ".$postedBy2."   ".$datePosted2;
              echo "<p>".$announcement2."</p>";
              
             
              echo "</tr>";
              
          

            }

         ?>
            </div>
            

            
             
          </form>
        </section>

    

 
    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  
  </body>
</html>
