

<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
	  <meta name="keywords" content="web design, affordable web design, professional web design">
  	<meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/style-tuition.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
           <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
      <div class="container">
        <form class="container" method ="post" action = "tuition-admin-add.php">
           <div class = "tuition-group">
              <div>
                <h2> Manage Tuition Fees</h2>
                <p> Welcome to tution summary page. Select the correct level to see how much is the tution fee for the currect school year. </p>
                
              </div>
              <div>
              <table>
                <tr>

                  <th colspan = 2>
                    <p><b>ASSESMENT OF FEES</b></p>
                  </th>
                </tr>
                 <tr>
                  <td>
                    <p> Enter Grade: </p>
                  </td>
                  <td>
                    <p> <input type="text" placeholder="Example: Grade 1, Grade 2 ..." name="gradeCode" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> Tution Fee: </p>
                  </td>
                  <td>
                    <p> <input type="text" placeholder="Tuition Fee" name="tuitionFee" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> Miscellaneous Fee:</p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="Miscellaneous Fee:" name="miscellaneousFee" required></p>
                  </td>
                </tr>
                 <tr>
                  <td>
                    <p> Books / PACE's Fee: </p>
                  </td>
                  <td>
                    <p> <input type="text" placeholder="Books / PACE's Fee:" name="booksFee" required></p>
                  </td>
                </tr>
                 <tr>
                  <td>
                    <p> Registration Fee: </p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="Registration Fee:" name="registrationFee" required></p>
                  </td>
                </tr>
                 <tr>
                  <td>
                    <p> Graduation Fee: </p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="Graduation Fee: " name="otherInstructionalFee" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> Other Instructional Fee: </p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="Other Instructional Fee: " name="uniformsFee" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> Uniforms: </p>
                  </td>
                  <td>
                    <p> <input type="text" placeholder=" Uniforms: " name="tuition" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> PTA Donation / Annual Fee: </p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="PTA Donation / Annual Fee: " name="ptaDonationFee" required></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p> Other Fees: </p>
                  </td>
                  <td>
                     <p> <input type="text" placeholder="Other Fees: " name="otherFee" required></p>
                  </td>
                </tr>
                <tr>
                  <div class = "total">
                    <td >
                      
                    </td>
                    <td>
                      <p> <input type="submit"  value = "Add" name="add_tuition" required></p>
                    </td>
                  </div>
                </tr>



              </table>
              </div>

            </div>
      </form>
      </div>
      
      
      

    </section>
  
    

    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>\
  </body>
</html>
<?php

$msg ="";

include_once '../resource/db.php';
include_once '../PHPMailer/Exception.php';
include_once '../PHPMailer/PHPMailer.php';
include_once '../PHPMailer/SMTP.php';



if (isset($_POST['add_tuition'])){
  $con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');   

  $gradeCode = $con->real_escape_string($_POST['gradeCode']);
  $tuitionFee = $con->real_escape_string($_POST['tuitionFee']);
  $miscellaneousFee = $con->real_escape_string($_POST['miscellaneousFee']);
  $booksFee = $con->real_escape_string($_POST['booksFee']);
  $registrationFee = $con->real_escape_string($_POST['registrationFee']);
  $otherInstructionalFee = $con->real_escape_string($_POST['otherInstructionalFee']);
  $uniformsFee = $con->real_escape_string($_POST['uniformsFee']);
  $ptaDonationFee = $con->real_escape_string($_POST['ptaDonationFee']);
  $otherFee = $con->real_escape_string($_POST['otherFee']);


  $sql = $con-> query("SELECT gradeCode FROM tuition WHERE LOWER(gradeCode)='$gradeCode'");
  if ($sql -> num_rows > 0) {
        echo '<script type = "text/javascript"> alert("Grade Code is already in the database!");</script>';
        exit;
  }
  
  $stmt2 = $dbconn->prepare('INSERT INTO tuition (gradeCode, tuitionFee, miscellaneousFee, booksFee, registrationFee, otherInstructionalFee, uniformsFee, ptaDonationFee, otherFee) VALUES (:gradeCode, :tuitionFee, :miscellaneousFee, :booksFee, :registrationFee, :otherInstructionalFee, :uniformsFee, :ptaDonationFee, :otherFee);');

  $stmt2->bindValue(':gradeCode', strtolower($gradeCode));
  $stmt2->bindValue(':tuitionFee', strtolower($tuitionFee));
  $stmt2->bindValue(':miscellaneousFee', strtolower($miscellaneousFee));
  $stmt2->bindValue(':booksFee', strtolower($booksFee));
  $stmt2->bindValue(':registrationFee', strtolower($registrationFee));
  $stmt2->bindValue(':otherInstructionalFee', strtolower($otherInstructionalFee));
  $stmt2->bindValue(':uniformsFee', strtolower($uniformsFee));
  $stmt2->bindValue(':ptaDonationFee', strtolower($ptaDonationFee));
  $stmt2->bindValue(':otherFee', strtolower($otherFee));
  $stmt2->execute();

  $mail = new PHPMailer\PHPMailer\PHPMailer();
  $mail->isSMTP();
  $mail->SMTPDebug = 0;
  $mail->Host = "smtp.gmail.com";
  $mail->Port = 587;
  $mail->SMTPSecure = 'tls';
  $mail->SMTPAuth = true;
  $mail->Username = 'mptercero@up.edu.ph';
  $mail->Password = 'seudriiwmozxuzdu';
  $mail->setFrom($mail->Username);
  $mail->addAddress($email);
  $mail->Subject = 'Your Account Registration';
  $message = '<p>Dear Admin,</p><p>You have successfully added record on the tution table. Have a great day!</p>';
  $mail->msgHTML($message);
  $mail->AltBody = strip_tags($message);
  $mail->send();
  echo '<script type = "text/javascript"> alert("<p>Grade Code is already added in the database!</>  <p><a href=tuition-admin-view.php>Click here</p>");</script>';
  echo '<META HTTP-EQUIV="Refresh" Content="0; URL=tuition-admin-view.php">';    
}
?>

