<?php

include_once 'resource/session.php';

session_destroy();
header('Location: admin-login.php');

