<?php
$msg = "";

include_once '../resource/session.php';
include_once '../resource/db.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}


$deleteAnnouncement = $_GET['id'];
$postedBy2 = "";
$announcement2 = "";
$datePosted2 = "";
$announcementTitle2 = "";
$id="";


$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');



$sql2 = $con-> query("SELECT * FROM announcement WHERE id = '$deleteAnnouncement';");
while($row2 = mysqli_fetch_array($sql2))

    {
      $postedBy2 = $row2['postedBy'];
      $announcement2 = $row2['announcement'];
      $datePosted2 = $row2['datePosted'];
      $announcementTitle2 = $row2['announcementTitle'];
     $id = $row2['id'];
    }



?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
    <meta name="keywords" content="web design, affordable web design, professional web design">
    <meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/style-form.css">
  </head>
  <body>  


    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
          <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
     
        <section id="boxes">
          <form class="container" method ="post" action = "update-announcement.php">
            <table style="width:100%">
              <tr>

                <td colspan = 4>
                  <div class = "" align = "left" style = "margin-left: 100px">
                    <p><?php echo $msg; ?></p>                    
                    <label for="fname"><b>Title:</b></label><br>
                    <input id = "" style = 'height: 30px; border-radius: 5px 10px; width: 965px;'  type="text" name="title" value = <?php echo $announcementTitle2; ?> /><br><br>
                    <input id = "" style = 'height: 30px; border-radius: 5px 10px; width: 965px;'  type="text" name="id" value = <?php echo $id; ?> /><br><br>
                    <label for="fname"><b>Update Announcement:</b></label><br>
                    <textarea id="comment" name="comment" style = 'border-radius: 5px 10px; font-family:"Century Gothic", Century Gothic, serif; font-size: 12px;' rows="9" cols="160" rows="9" cols="130"><?php echo $announcement2; ?></textarea><br>

                     <div class = "" align = "right" style = "margin-bottom: 30px; margin-top: 30px;">
                        <input type="submit" name = "UpdateAnnoucement" value = "Update Announcement">
                    </div>
                  </div>
                </td> 
              </tr>
            </div>
            </tr>

            </table>
             
          </form>
        </section>
    
      

    </section>


    


    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
