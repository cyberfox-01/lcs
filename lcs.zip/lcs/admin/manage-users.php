
<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}

if ($_SESSION['username'] != "mptercero@up.edu.ph")
{   
    echo '<script type = "text/javascript"> alert("You are not allowed to access this page. Only school principal can access this page.");</script>';
    header("Location: home-admin.php");
}


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
	  <meta name="keywords" content="web design, affordable web design, professional web design">
  	<meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/style-tuition.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
           <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
      <div class="container">
        <div class="container">
           <div class = "tuition-group">
              <div>
                <h2> Manage User</h2>
                <p> Welcome to tution Admin Users page. You can add, delete or update Admin User Credentials</p>

              </div>
              <div>
              <table>
                <tr>

                  <th colspan = 12>
                    <p><b>LIST of ADMIN USERS</b></p>
                  </th>
                </tr>
                <?php
                    echo "<tr>
                            <th>Admin Name</th>
                            <th>Email Address</th>
                            <th>Email Confirmation</th>
                            <th>Manage User</th>
                            
                           
                      </tr>";


                    include_once '../resource/db.php';
                    

                    
                      $con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');   
                      $sql = $con-> query("SELECT * FROM admin;");
                      while($row = mysqli_fetch_array($sql))
                        {
                          if ($row['isEmailConfirmed'] == 0)
                            $interpret="No";
                          else
                            $interpret = "Yes";
                        echo "<form method=post action=update-delete.php>";
                        echo "<tr>";
                        echo "<td>" .$row['name'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" .$interpret. "</td>";


                      
                        echo "<td><p style =color: green; font-size: 10px;><a href=http://tercerotaton.cf/lcs/includes/deleteuser.php?id=".$row['email'].">Delete</a></td>";

                        echo "</tr>";
                        
                        echo "</form>";
                        
              
                        }
                        echo "<td colspan = 11><a href=add-admin-user.php>Add New Admin User</a></td>";


                    
                ?>
              </table>
              </div>

            </div>
      </div>
      </div>
      
      
      

    </section>

    
    

    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
