<?php
$msg = "";

include_once '../resource/session.php';
include_once '../resource/db.php';


if (isset($_POST['UpdateAnnoucement'])){

  $postedBy = $_SESSION['username'];
  $announcement = $_POST['comment'];
  $datePosted = date("Y-m-d h:i:sa");
  $announcementTitle = $_POST['title'];
  $id = $_POST['id'];

  $sql = "UPDATE announcement SET postedBy = :postedBy, 
                          announcement = :announcement, 
                          datePosted = :datePosted,  
                          announcementTitle = :announcementTitle
                          WHERE id = :id";

  $stmt2 = $dbconn->prepare($sql);

  $stmt2->bindValue(':postedBy', $postedBy);
  $stmt2->bindValue(':datePosted', $datePosted);
  $stmt2->bindValue(':announcement', $announcement);
  $stmt2->bindValue(':announcementTitle', $announcementTitle);
  $stmt2->bindValue(':id', $id);


 if ($stmt2->execute()){
       echo '<script type = "text/javascript"> alert("Announcement has been succesfully updated.");</script>';
      header("Location: add-announcements.php");

    }else{
        echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
    }
}



?>