

<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}
?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
    <meta name="keywords" content="LCS Online Enrollment System">
    <meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="../css/style-admin.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
           <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>
    <section id="showcase">
      <div class="container">
        <h1><span class = "highlight">LCS</span> Administration Panel</h1>
        
      </div>
      
        <section id="boxes">
          <div class="container">
            <div class="box">
              <img src="/lcs/img/proess-enrollment.png">
              <h3><a href="process-enrollment-old.php">OLD STUDENTS</a> | <a href="process-enrollment-new.php">NEW/TRANSFEREES</a></h3>
              <p>Process Enrollment: If processing old students, select OLD STUDENT, else, select NEW/TRANSFEREE</p>
            </div>
            <div class="box">
              <a href= "add-student-payment.php"><img src="/lcs/img/update-payment.png"></a>
              <h3>Update Student Payment</h3>
              <p>Click the icon above to add payment.</p>
            </div>
            <div class="box">
              <a href= "tuition-admin-view.php"><img src="/lcs/img/enrollment-icon.png"></a>
              <h3>Update Tuition Fee</h3>
              <p>Click the icon above to update tuition fee metrics.</p>
            </div>
          </div>
        </section>
        <section id="boxes">
          <div class="container">
            <div class="box">
              <img src="/lcs/img/add-annoucement.png">
              <h3>Add Annoucement</h3>
              <p>Please click the icon above to add annoucement.</p>
            </div>
            <div class="box">
              <a href= "data-insights-for-enrollments.php"><img src="/lcs/img/statistics.png"></a>
              <h3>View Enrollment Statistics</h3>
              <p>Click the icon above to see data insights.</p>
            </div>
            <div class="box">
              <a href="add-admin-user.php"><img src="/lcs/img/student-payment.png"></a>
              <h3>Add Admin Users</h3>
              <p>Click the icon above to add admin users.</p>
            </div>
          </div>
        </section>
    
      

    </section>



    


    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
