<?php

include_once '../resource/session.php';

$parts = explode("@", $_SESSION['username']);
$username = $parts[0];

if (!isset($_SESSION['id']))
{
    header("Location: admin-login.php");
    die();
}
?>



<?php

$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');
$studentID = $con->real_escape_string($_GET['studentID']);



      function redirect() {
      header('Location: home-admin.php');
      exit();
    }


if (!isset($_GET['studentID'])) {
          redirect();
          } else {
            

            
          

            $sql = $con->query("SELECT * FROM enrollee WHERE studentID = '$studentID'");

            while($row = mysqli_fetch_array($sql)) {
                          $agreement = "";
                          $enrollmentStatus = $row['enrollmentStatus'];
                          $isApproved = $row['isApproved'];
                          $isPassed = $row['isPassed'];
                          $enrolledWhen = date("Y-m-d");
                          $enrolledBy = $row['enrolledBy'];
                          $studentID = $row['studentID'];
                          $gradeLevel = $row['gradeLevel'];    
                          $enrolledByEmailAddress = $row['enrolledByEmailAddress'];
                          $enrolleeLastName = $row['enrolleeLastName'];
                          $enrolleeFirstName = $row['enrolleeFirstName'];
                          $enrolleeMiddleName = $row['enrolleeMiddleName'];
                          $enrolleeGender = $row['enrolleeGender'];
                          $enrolleeAge = $row['enrolleeAge'];
                          $enrolleeBirthday = $row['enrolleeBirthday'];
                          $enrolleeBirthPlace = $row['enrolleeBirthPlace']; 
                          $enrolleeHouseNo = $row['enrolleeHouseNo']; 
                          $enrolleeStreet = $row['enrolleeStreet'];
                          $enrolleeBarangay = $row['enrolleeBarangay'];
                          $enrolleeMunicipality = $row['enrolleeMunicipality'];
                          $enrolleeProvince = $row['enrolleeProvince'];
                          $enrolleeCountry = $row['enrolleeCountry'];
                          $enrolleeZipCode = $row['enrolleeZipCode'];
                          $enrolleeMotherName = $row['enrolleeMotherName'];
                          $enrolleeFatherName = $row['enrolleeFatherName'];
                          $enrolleeMotherPhone = $row['enrolleeMotherPhone'];
                          $enrolleeFatherPhone = $row['enrolleeFatherPhone'];
                          $motherOtherContacts =  $row['motherOtherContacts'];
                          $fatherOtherContacts = $row['fatherOtherContacts'];
                          $enrolleeGuardian = $row['enrolleeGuardian'];
                          $enrolleeSchoolServiceName = $row['enrolleeSchoolServiceName'];
                          $servicePlateNumber = $row['servicePlateNumber']; 
                          $servicePhoneNumber = $row['servicePhoneNumber'];
                          $enrolleePSANo = $row['enrolleePSANo'];
                          $enrolleeLRN =  $row['enrolleeLRN'];
                          $enrolleeCode = $row['enrolleeCode'];
                          $enrolleeRefNo = $row['enrolleeRefNo'];
                          $_SESSION['studentID'] = $studentID;
               }
  }




                          
                       
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
    <meta name="keywords" content="web design, affordable web design, professional web design">
    <meta name="author" content="Marlon Tercero">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="/lcs/css/style-form.css">
  </head>
  <body>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
    </script>

    <script type="text/javascript">


        function updatebox()
              {
                  var textbox = document.getElementById("comment");
                  var values = [];

                  if(document.getElementById('tuitionFee').checked) {
                      values.push("Tuition Fee\n");
                  }

                  if(document.getElementById('miscellaneousFee').checked) {
                      values.push("Miscellaneous Fee\n");
                  }

                  if(document.getElementById('bookFee').checked) {
                      values.push("Book Fee\n");
                  }
                   if(document.getElementById('registrationFee').checked) {
                      values.push("Registration Fee\n");
                  }

                   if(document.getElementById('otherInstructionalFee').checked) {
                      values.push("Other Instructional Fee\n");
                  }
                  if(document.getElementById('uniformFee').checked) {
                      values.push("Uniform Fee\n");
                  }
                   if(document.getElementById('ptaDonationFee').checked) {
                      values.push("PTA Donation Fee\n");
                  }
                  if(document.getElementById('otherFees').checked) {
                      values.push("Other Fees\n");
                  }
                  

                  textbox.value = values.join(" ");
              }

       
    </script>


    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
          <ul class = "main-menu">
            <li class="current"><a href="home-admin.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a>
                <ul class="sub-menu">
                  <li><a href="tuition-admin-view.php">Manage Tuition Fees</a></li>
                  <li><a href="add-student-payment.php">Update Student Payment</a></li>
                  <li><a href="add-announcements.php">Add Annoucement</a></li>
                  <li><a href="process-enrollment-new.php">Process Enrollment: New/Transferee Students</a></li>
                  <li><a href="process-enrollment-old.php">Process Enrollment: Old Students</a></li>
                  <li><a href="data-insights-for-enrollments.php">View Enrollment Data Insights</a></li>
                </ul></li>

              </li>
              <li><a href="logout.php">Log Out</a><?php  echo ' '.$username  ?></li>

  
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
     
        <section id="boxes">
          <form class="container" method ="post" action = "add-payment-for-student.php">
            <table style="width:100%">

              </tr>
              <tr>
                <td colspan = 5><br><b>______________________________________________________________________________________________________________________________________</b></td>

              </tr>
              <tr>
                <td colspan = 5><b>STUDENT'S PERSONAL RECORD</b></td>

              </tr>
              <tr>
                <td colspan = 5>_____________________________________________________________________________________________________________________________________</td>

              </tr>

             
              <tr>
                <td>
                  <div class = "input-group-signup">
                    <label for="lname"><b>Last Name:</b></label>
                    <input type="text" placeholder="Enter Last Name" name="enrolleeLastName" value = "<?php echo $enrolleeLastName; ?>">
                     <label for="fname"><b>First Name:</b></label>
                    <input type="text" placeholder="Enter first name" name="enrolleeFirstName" value = "<?php echo $enrolleeFirstName; ?>"required>
                     <label for="mname"><b>Middle Name:</b></label>
                    <input type="text" placeholder="Enter middle name" name="enrolleeMiddleName" value = "<?php echo $enrolleeMiddleName; ?>"required>
                    <label for="newEnrollee"><b>Enrollee Type:</b></label>
                     <input type="text" placeholder="Enter middle name" name="enrolleeMiddleName" value = "<?php echo $enrolleeCode; ?>"required>
                    <label for="refNumber"><b>Student Number:</b></label>
                    <input type="text" name="studentID" value = "<?php echo $studentID; ?>" >
                    <label for="gradeLevel"><b>Grade Level:</b></label>
                    <input type="text" name="gradeLevel" value = "<?php echo $gradeLevel; ?>" >
                    <label for="gender"><b>Gender:</b></label>
                    <input type="text" name="enrolleeGender" value = "<?php echo $enrolleeGender; ?>" >
                    <label for="gender"><b>Age:</b></label>
                    <input type="text" name="enrolleeAge" value = "<?php echo $enrolleeAge; ?>" >
                    <label for="gender"><b>Email Address:</b></label>
                    <input type="text" name="enrolledByEmailAddress" value = "<?php echo $enrolledByEmailAddress; ?>" >

                  </div>
                </td>

                <td>
                  <div class = "" align = "left" style = "margin-left: 100px">
                    <label for="payment"><b>Enter Tuition Fee:</b></label>
                    <input type="text" placeholder="" name="amountPaid" required> <br><br>
                    <label for="fname"><b>Select Paid Items:</b></label><br>

                    &nbsp;&nbsp;&nbsp;<input id = "tuitionFee"  type="checkbox" value="Tuition Fee" onclick="updatebox()"/>Tuition Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "miscellaneousFee" type="checkbox" value="Miscellaneous Fee" onclick="updatebox()"/ >Miscellaneous Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "bookFee" type="checkbox"  value="Book Fee" onclick = "updatebox()"/>Book Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "registrationFee" type="checkbox" value="Registration Fee" onclick="updatebox()"/>Registration Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "otherInstructionalFee" type="checkbox" value="Other Instructional Fee" onclick="updatebox()"/>Other Instructional Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "uniformFee" type="checkbox" value="Uniform Fee" onclick="updatebox()"/>Uniform Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "ptaDonationFee" type="checkbox" value="PTA Donation Fee" onclick="updatebox()"/>PTA Donation Fee<br>
                     &nbsp;&nbsp;&nbsp;<input id = "otherFees" type="checkbox" value="Other Fees" onclick="updatebox()"/>Other Fees<br><br>

                    <label for="comments"><b>Comments:</b></label> <br>
                    <textarea id="comment" name="comment"
                        rows="9" cols="100">
                
                    </textarea><br>

                     <div class = "input-group-short" align = "right">
                        <input type="submit" name = "AddPayment" value = "Add Payment">
                    </div>


               



                    

                  </div>
                </td>


                
              </tr>

             
              

                     <?php

                             echo "<table style='border: 1px solid orange;'>";
                            echo "<tr style='border: 1px solid orange;'>";
                            echo "<th style='border: 1px solid orange;'> Total Amound Paid </th>";
                            echo "<th style='border: 1px solid orange;'>Payment Date   </th>";
                            echo "<th style='border: 1px solid orange;'> Notes/Comments</th>";
                            echo "<th style='border: 1px solid orange;'> Processed By </th>";
                            echo "</tr>";

                            $sql2 = $con->query("SELECT * FROM studentpayments WHERE studentID = '$studentID'");

                            while($row2 = mysqli_fetch_array($sql2)) {
                                      echo "<tr style='border: 1px solid orange;'>";
                                      echo "<td style='border: 1px solid orange;'><p>PHP ".$row2['amountPaid'].".00</p></td>";
                                      echo "<td style='border: 1px solid orange;'><p>".$row2['paymentMadeWhen']."</p></td>";
                                      echo "<td style='border: 1px solid orange;'><p>".$row2['descriptions']."</p></td>";
                                      echo "<td style='border: 1px solid orange;'><p>".$row2['paymentProcessedBy']."</p></td>";
                                      echo "</tr>";
                                          

                    }
                    echo "</table>";

               ?>


            </table>
             
          </form>
        </section>
    
      

    </section>


    


    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
