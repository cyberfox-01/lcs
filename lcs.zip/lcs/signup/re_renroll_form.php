<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="LCS Online Enrollment System">
	  <meta name="keywords" content="web design, affordable web design, professional web design">
  	<meta name="author" content="Brad Traversy">
    <title>Lucban Christian School | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Lucban</span> Christian School</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="services.html">Services</a></li>
          </ul>
        </nav>
      </div>
    </header>
    <section id="showcase">
      <div class="container">
        <p><span class = "highlight">Fill-up the following information to enroll</p>
        
      </div>
      
        <section id="boxes">
          <div class="container">
            <div class="box">
              <img src="./img/logo_html.png">
              <h3>New Student</h3>
              <p>If you are  new student, please click the icon above to enroll.</p>
            </div>
            <div class="box">
              <img src="./img/logo_css.png">
              <h3>Old Student</h3>
              <p>If re-enrolling for the coming schoo year, click the icon above to enroll.</p>
            </div>
            <div class="box">
              <img src="./img/logo_brush.png">
              <h3>Transferee</h3>
              <p>If transferee, click the icon above to enroll.</p>
            </div>
          </div>
        </section>
    
      

    </section>


    


    <footer>
      <p>Lucban Christian School, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
