<?php

include_once '../resource/db.php';
include_once '../resource/session.php';


 if(isset($_POST['update_record'])){
                          //con = new mysqli('localhost', 'root', '', 'lcs');  

                          /*$gradeCode = $_POST['gradeCode'];
                          $tuitionFee = $_POST['tuitionFee'];
                          $miscellaneousFee = $_POST['miscellaneousFee'];
                          $booksFee = $_POST['booksFee'];
                          $registrationFee = $_POST['registrationFee'];
                          $otherInstructionalFee = $_POST['otherInstructionalFee'];
                          $uniformsFee = $_POST['uniformsFee'];
                          $ptaDonationFee = $_POST['ptaDonationFee'];
                          $otherFee = $_POST['otherFee']);

                          $gradeCode_lower = strtolower($gradeCode);*/


                          $sql = "UPDATE tuition SET tuitionFee = :tuitionFee, 
                          miscellaneousFee = :miscellaneousFee, 
                          booksFee = :booksFee,  
                          registrationFee = :registrationFee,  
                          otherInstructionalFee = :otherInstructionalFee,
                          uniformsFee = :uniformsFee,
                          ptaDonationFee = :ptaDonationFee,
                          otherFee = :otherFee
                          WHERE LOWER(gradeCode) = :gradeCode";

                          $stmt = $dbconn->prepare($sql);                                  
                          $stmt->bindParam(':tuitionFee', $_POST['tuitionFee']);       
                          $stmt->bindParam(':miscellaneousFee', $_POST['miscellaneousFee']);    
                          $stmt->bindParam(':booksFee', $_POST['booksFee']);
                          $stmt->bindParam(':registrationFee', $_POST['registrationFee']); 
                          $stmt->bindParam(':otherInstructionalFee', $_POST['otherInstructionalFee']);   
                          $stmt->bindParam(':uniformsFee', $_POST['uniformsFee']);
                          $stmt->bindParam(':ptaDonationFee', $_POST['ptaDonationFee']);
                          $stmt->bindParam(':otherFee', $_POST['otherFee']);
                          $stmt->bindParam(':gradeCode', strtolower($_POST['gradeCode']));
                          if ($stmt->execute()){
                             echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';
                             header("Location: tuition-admin-view.php");
                          }else{
                              echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                          }
                       

                         
                  
                            //echo '<script type = "text/javascript"> alert("Error updating record.");</script>';

                       

                          


                      }

?>