<?php

include_once '../resource/db.php';
include_once '../resource/session.php';


 if(isset($_POST['enroll'])){
                          //con = new mysqli('localhost', 'root', '', 'lcs');  

                          /*$gradeCode = $_POST['gradeCode'];
                          $tuitionFee = $_POST['tuitionFee'];
                          $miscellaneousFee = $_POST['miscellaneousFee'];
                          $booksFee = $_POST['booksFee'];
                          $registrationFee = $_POST['registrationFee'];
                          $otherInstructionalFee = $_POST['otherInstructionalFee'];
                          $uniformsFee = $_POST['uniformsFee'];
                          $ptaDonationFee = $_POST['ptaDonationFee'];
                          $otherFee = $_POST['otherFee']);

                          $gradeCode_lower = strtolower($gradeCode);*/


                          $sql = "INSERT INTO enrollee (agreedToTerms,
                                  enrolledBy,
                                  enrolledByEmailAddress,
                                  enrolledWhen,
                                  enrollee137,
                                  enrollee138,
                                  enrolleeAddress,
                                  enrolleeAge,
                                  enrolleeBarangay,
                                  enrolleeBirthday,
                                  enrolleeBirthPlace,
                                  enrolleeCode,
                                  enrolleeCountry,
                                  enrolleeFatherName,
                                  enrolleeFatherPhone,
                                  enrolleeFirstName,
                                  enrolleeGender,
                                  enrolleeGMC,
                                  enrolleeGuardian,
                                  enrolleeHouseNo,
                                  enrolleeLastName,
                                  enrolleeLRN,
                                  enrolleeMiddleName,
                                  enrolleeMotherName,
                                  enrolleeMotherPhone,
                                  enrolleeMunicipality,
                                  enrolleeNSO,
                                  enrolleeProvince,
                                  enrolleePSANo,
                                  enrolleeRefNo,
                                  enrolleeSchoolServiceName,
                                  enrolleeStreet,
                                  enrolleeZipCode,
                                  fatherOtherContacts,
                                  gradeLevel,
                                  isApproved,
                                  isPassed,
                                  motherOtherContacts,
                                  servicePhoneNumber,
                                  servicePlateNumber,
                                  studentID,
                                  enrollmentStatus) VALUES (
                                  :agreedToTerms,
                                  :enrolledBy,
                                  :enrolledByEmailAddress,
                                  :enrolledWhen,
                                  :enrollee137,
                                  :enrollee138,
                                  :enrolleeAddress,
                                  :enrolleeAge,
                                  :enrolleeBarangay,
                                  :enrolleeBirthday,
                                  :enrolleeBirthPlace,
                                  :enrolleeCode,
                                  :enrolleeCountry,
                                  :enrolleeFatherName,
                                  :enrolleeFatherPhone,
                                  :enrolleeFirstName,
                                  :enrolleeGender,
                                  :enrolleeGMC,
                                  :enrolleeGuardian,
                                  :enrolleeHouseNo,
                                  :enrolleeLastName,
                                  :enrolleeLRN,
                                  :enrolleeMiddleName,
                                  :enrolleeMotherName,
                                  :enrolleeMotherPhone,
                                  :enrolleeMunicipality,
                                  :enrolleeNSO,
                                  :enrolleeProvince,
                                  :enrolleePSANo,
                                  :enrolleeRefNo,
                                  :enrolleeSchoolServiceName,
                                  :enrolleeStreet,
                                  :enrolleeZipCode,
                                  :fatherOtherContacts,
                                  :gradeLevel,
                                  :isApproved,
                                  :isPassed,
                                  :motherOtherContacts,
                                  :servicePhoneNumber,
                                  :servicePlateNumber,
                                  :studentID,
                                  :enrollmentStatus");

                          $stmt = $dbconn->prepare($sql);                                  
                          $stmt->bindParam(':agreedToTerms', $_POST['agreedToTerms']);       
                          $stmt->bindParam(':enrolledBy', $_POST['enrolledBy']);    
                          $stmt->bindParam(':enrolledByEmailAddress', $_POST['enrolledByEmailAddress']);
                          $stmt->bindParam(':enrolledWhen', $_POST['enrolledWhen']); 
                          $stmt->bindParam(':enrollee137', $_POST['enrollee137']);   
                          $stmt->bindParam(':enrollee138', $_POST['enrollee138']);
                          $stmt->bindParam(':enrolleeAddress', $_POST['enrolleeAddress']);
                          $stmt->bindParam(':enrolleeAge', $_POST['enrolleeAge']);
                          $stmt->bindParam(':enrolleeBarangay', strtolower($_POST['enrolleeBarangay']));
                          $stmt->bindParam(':enrolleeBirthday', $_POST['enrolleeBirthday']);       
                          $stmt->bindParam(':enrolleeBirthPlace', $_POST['enrolleeBirthPlace']);    
                          $stmt->bindParam(':enrolleeCode', $_POST['enrolleeCode']);
                          $stmt->bindParam(':enrolleeCountry', $_POST['enrolleeCountry']); 
                          $stmt->bindParam(':enrolleeFatherName', $_POST['enrolleeFatherName']);   
                          $stmt->bindParam(':enrolleeFatherPhone', $_POST['enrolleeFatherPhone']);
                          $stmt->bindParam(':enrolleeFirstName', $_POST['enrolleeFirstName']);
                          $stmt->bindParam(':enrolleeGender', $_POST['enrolleeGender']);
                          $stmt->bindParam(':enrolleeGMC', strtolower($_POST['enrolleeGMC']));
                          $stmt->bindParam(':enrolleeGuardian', $_POST['enrolleeGuardian']);       
                          $stmt->bindParam(':enrolleeHouseNo', $_POST['enrolleeHouseNo']);    
                          $stmt->bindParam(':enrolleeLastName', $_POST['enrolleeLastName']);
                          $stmt->bindParam(':enrolleeLRN', $_POST['enrolleeLRN']); 
                          $stmt->bindParam(':enrolleeMiddleName', $_POST['enrolleeMiddleName']);   
                          $stmt->bindParam(':enrolleeMotherName', $_POST['enrolleeMotherName']);
                          $stmt->bindParam(':enrolleeMotherPhone', $_POST['enrolleeMotherPhone']);
                          $stmt->bindParam(':enrolleeMunicipality', $_POST['enrolleeMunicipality']);
                          $stmt->bindParam(':enrolleeNSO', strtolower($_POST['enrolleeNSO']));
                          $stmt->bindParam(':enrolleeProvince', $_POST['enrolleeProvince']);          
                          $stmt->bindParam(':enrolleePSANo', $_POST['enrolleePSANo']);
                          $stmt->bindParam(':enrolleeRefNo', $_POST['enrolleeRefNo']); 
                          $stmt->bindParam(':enrolleeSchoolServiceName', $_POST['enrolleeSchoolServiceName']);   
                          $stmt->bindParam(':enrolleeStreet', $_POST['enrolleeStreet']);
                          $stmt->bindParam(':enrolleeZipCode', $_POST['enrolleeZipCode']);
                          $stmt->bindParam(':fatherOtherContacts', $_POST['fatherOtherContacts']);
                          $stmt->bindParam(':gradeLevel', strtolower($_POST['gradeLevel']));
                          $stmt->bindParam(':isApproved', $_POST['isApproved']);
                          $stmt->bindParam(':isPassed', $_POST['isPassed']);
                          $stmt->bindParam(':motherOtherContacts', $_POST['motherOtherContacts']);
                          $stmt->bindParam(':servicePhoneNumber', strtolower($_POST['servicePhoneNumber']));
                          $stmt->bindParam(':servicePlateNumber', $_POST['servicePlateNumber']);
                          $stmt->bindParam(':studentID', strtolower($_POST['studentID']));
                          $stmt->bindParam(':enrollmentStatus', strtolower($_POST['enrollmentStatus']));

                          if ($stmt->execute()){
                             echo '<script type = "text/javascript"> alert("Record updated successfully");</script>';
                      
                          }else{
                              echo '<script type = "text/javascript"> alert("There was an issue encountered!");</script>';
                          }
                       

                         
                  
                            //echo '<script type = "text/javascript"> alert("Error updating record.");</script>';

                       

                          


                      }

?>