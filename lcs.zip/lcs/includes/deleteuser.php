<?php

include_once '../resource/db.php';
include_once '../resource/session.php';

$deleteuser = $_GET['id'];

$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');    
    
$sql = $con-> query("DELETE FROM admin WHERE email='$deleteuser'");
header("Location: ../admin/manage-users.php");

?>