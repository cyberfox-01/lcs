<?php

 if(isset($_POST['viewTuition'])){
                    include_once '../resource/db.php';
                    include_once '../resource/session.php';

                    $gradeLevel = strtolower($_POST['gradeLevel']);

                    
                      $con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');   
                      $sql = $con-> query("SELECT * FROM tuition WHERE gradeCode ='grade 1'/*LOWER(gradeCode) = $gradeLevel*/");
                      while($row = mysqli_fetch_array($sql))
                        {

                        $tuitionFee = $row['tuitionFee'];
                        $miscellaneousFee = $row['miscellaneousFee'];
                        $booksFee = $row['booksFee'];
                        $registrationFee= $row['registrationFee'];
                        $otherInstructionalFee = $row['otherInstructionalFee'];
                        $uniformsFee = $row['uniformsFee'];
                        $ptaDonationFee = $row['ptaDonationFee'];
                        $otherFee = $row['otherFee'];

                        echo "<form method=post action=none>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" .$tuitionFee. "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" .$tuitionFee. "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['tuitionFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['miscellaneousFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['booksFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['registrationFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['otherInstructionalFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['uniformsFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['ptaDonationFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "<td>" . $row['otherFee'] . "</td>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td>Tuition Fee</td>";
                        echo "</tr>";
                        
                        echo "<td>" ."<input type=hidden name=hidden value='" . $row['gradeCode'] . "'>"."<input type=submit name=update value=update" . " </td>";
                        echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
                        echo "</tr>";
                        
                        echo "</form>";
                        

              
                        }

            }


                    
?>