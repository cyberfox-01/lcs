<?php  
$fileDestination ="";
                          $fileDestination1 = "";
                          $fileDestination2 = "";
                          $fileDestination3 = "";
                          if(isset($_FILES['enrolleeNSO'])) {
                                $file = $_FILES['enrolleeNSO'];
                                echo $file;

                                $fileName = $_FILES['enrolleeNSO']['name'];
                                $fileTmpName = $_FILES['enrolleeNSO']['tmp_name'];
                                $fileSize = $_FILES['enrolleeNSO']['size'];
                                $fileError = $_FILES['enrolleeNSO']['error'];
                                $fileType = $_FILES['enrolleeNSO']['type'];



                                $fileExt = explode('.', $fileName);
                                $fileActualExt = strtolower(end($fileExt));
                                $fileActualName = strtolower($fileExt[0]);


                                $allowed = array('jpg', 'jpeg', 'png', 'pdf');

                                if(in_array($fileActualExt, $allowed)){
                                    if ($fileError === 0){
                                        if (fileSize < 1000000){
                                            $fileNameNew = $fileActualName.uniqid('', true).".".$fileActualExt;
                                            $fileDestination = "/upload/".$fileNameNew;
                                            echo $fileDestination;
                                            move_uploaded_file( $fileTmpName, $fileDestination);
                                        }else{
                                            echo "You file is too big!";
                                        }

                                    }else{
                                        echo "There was a problem uploading the file";
                                    }

                                }else{
                                    echo "Only 'jpg', 'jpeg', 'png', 'pdf' are allowed for upload.";
                                }
                            }



                          if(isset($_FILES['enrollee137'])) {
                              $file1 = $_FILES['enrollee137'];

                              $fileName1 = $_FILES['enrollee137']['name'];
                              $fileTmpName1 = $_FILES['enrollee137']['tmp_name'];
                              $fileSize1 = $_FILES['enrollee137']['size'];
                              $fileError1 = $_FILES['enrollee137']['error'];
                              $fileType1 = $_FILES['enrollee137']['type'];



                              $fileExt1 = explode('.', $fileName1);
                              $fileActualExt1 = strtolower(end($fileExt1));
                              $fileActualName1 = strtolower($fileExt1[0]);


                              $allowed1 = array('jpg', 'jpeg', 'png', 'pdf');

                              if(in_array($fileActualExt1, $allowed1)){
                                  if ($fileError1 === 0){
                                      if (fileSize < 1000000){
                                          $fileNameNew1 = $fileActualName1.uniqid('', true).".".$fileActualExt1;
                                          $fileDestination1 = "/upload/".$fileNameNew1;
                                          echo $fileDestination1;
                                          move_uploaded_file( $fileTmpName1, $fileDestination1);
                                      }else{
                                          echo "You file is too big!";
                                      }

                                  }else{
                                      echo "There was a problem uploading the file";
                                  }

                              }else{
                                  echo "Only 'jpg', 'jpeg', 'png', 'pdf' are allowed for upload.";
                              }
                          }



                          if(isset($_FILES['enrollee138'])) {
                              $file2 = $_FILES['enrollee138'];

                              $fileName2 = $_FILES['enrollee138']['name'];
                              $fileTmpName2 = $_FILES['enrollee138']['tmp_name'];
                              $fileSize2 = $_FILES['enrollee138']['size'];
                              $fileError2 = $_FILES['enrollee138']['error'];
                              $fileType2 = $_FILES['enrollee138']['type'];



                              $fileExt2 = explode('.', $fileName2);
                              $fileActualExt2 = strtolower(end($fileExt2));
                              $fileActualName2 = strtolower($fileExt2[0]);


                              $allowed2 = array('jpg', 'jpeg', 'png', 'pdf');

                              if(in_array($fileActualExt2, $allowed2)){
                                  if ($fileError2 === 0){
                                      if (fileSize < 1000000){
                                          $fileNameNew2 = $fileActualName2.uniqid('', true).".".$fileActualExt2;
                                          $fileDestination2 = "/upload/".$fileNameNew2;
                                          echo $fileDestination2;
                                          move_uploaded_file( $fileTmpName2, $fileDestination2);
                                      }else{
                                          echo "You file is too big!";
                                      }

                                  }else{
                                      echo "There was a problem uploading the file";
                                  }

                              }else{
                                  echo "Only 'jpg', 'jpeg', 'png', 'pdf' are allowed for upload.";
                              }
                          }

                          if(isset($_FILES['enrolleeGMC'])) {
                              $file3 = $_FILES['enrolleeGMC'];

                              $fileName3 = $_FILES['enrolleeGMC']['name'];
                              $fileTmpName3 = $_FILES['enrolleeGMC']['tmp_name'];
                              $fileSize3 = $_FILES['enrolleeGMC']['size'];
                              $fileError3 = $_FILES['enrolleeGMC']['error'];
                              $fileType3 = $_FILES['enrolleeGMC']['type'];

                              $fileExt3 = explode('.', $fileName3);
                              $fileActualExt3 = strtolower(end($fileExt3));
                              $fileActualName3 = strtolower($fileExt3[0]);


                              $allowed3 = array('jpg', 'jpeg', 'png', 'pdf');

                              if(in_array($fileActualExt3, $allowed3)){
                                  if ($fileError3 === 0){
                                      if (fileSize < 1000000){
                                         $fileNameNew3 = $fileActualName3.uniqid('', true).".".$fileActualExt3;
                                          $fileDestination3 = "/upload/".$fileNameNew3;
                                          echo $fileDestination3;
                                          move_uploaded_file( $fileTmpName3, $fileDestination3);
                                      }else{
                                          echo "You file is too big!";
                                      }

                                  }else{
                                      echo "There was a problem uploading the file";
                                  }

                              }else{
                                  echo "Only 'jpg', 'jpeg', 'png', 'pdf' are allowed for upload.";
                              }
                          }


