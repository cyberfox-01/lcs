<?php
//include connection file 

$booksFee ="";
$miscellaneousFee = "";
$otherFee = "";
$otherInstructionalFee = "";
$ptaDonationFee = "";
$registrationFee = "";
$tuitionFee = "";
$uniformsFee = "";
$totalFees ="";

include_once '../resource/db.php';
include_once '../resource/session.php';

      $parts = explode("@", $_SESSION['username']);
      $username = $parts[0];

      if (!isset($_SESSION['id'])){
          header("Location: ../lcs/login.php");
          die();
      }





$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');
$sql = $con->query("SELECT name FROM users WHERE email='$_SESSION[username]'");
   while($row = mysqli_fetch_array($sql)) {
    $name=$row['name'];

   }


 

 if(isset($_POST['generatePDF'])){

                         $gradeLevel2 = strtolower($_POST['gradeLevel']);
                            $con2 = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');
                            $sql2 = $con2->query("SELECT * FROM tuition WHERE LOWER(gradeCode)='$gradeLevel2'");
                               while($row2 = mysqli_fetch_array($sql2)){

                                $booksFee = $row2['booksFee'];
                                $miscellaneousFee = $row2['miscellaneousFee'];
                                $otherFee = $row2['otherFee'];
                                $otherInstructionalFee = $row2['otherInstructionalFee'];
                                $ptaDonationFee = $row2['ptaDonationFee'];
                                $registrationFee = $row2['registrationFee'];
                                $tuitionFee = $row2['tuitionFee'];
                                $uniformsFee = $row2['uniformsFee'];

                                $totalFees = $booksFee + $miscellaneousFee + $otherFee + $otherInstructionalFee + $ptaDonationFee + $registrationFee + $tuitionFee + $uniformsFee;

                               }

                          $agreement = 1;
                          $enrollmentStatus = "Pending";
                          $isApproved = "Not Evaluated";
                          $isPassed = "Not Evaluated";
                          $enrolledWhen = date("Y-m-d");
                          $enrolledBy = $name;
                          $studentID = $_SESSION['studentID'];
                          $gradeLevel = $_POST['gradeLevel'];    
                          $enrolledByEmailAddress = $_SESSION['username'];
                          $enrolleeLastName = $_POST['enrolleeLastName'];
                          $enrolleeFirstName = $_POST['enrolleeFirstName'];
                          $enrolleeMiddleName = $_POST['enrolleeMiddleName'];
                          $enrolleeGender = $_POST['enrolleeGender'];
                          $enrolleeAge = $_POST['enrolleeAge'];
                          $enrolleeBirthday = $_POST['enrolleeBirthday'];
                          $enrolleeBirthPlace = $_POST['enrolleeBirthPlace']; 
                          $enrolleeHouseNo = $_POST['enrolleeHouseNo']; 
                          $enrolleeStreet = $_POST['enrolleeStreet'];
                          $enrolleeBarangay = $_POST['enrolleeBarangay'];
                          $enrolleeMunicipality = $_POST['enrolleeMunicipality'];
                          $enrolleeProvince = $_POST['enrolleeProvince'];
                          $enrolleeCountry = $_POST['enrolleeCountry'];
                          $enrolleeZipCode = $_POST['enrolleeZipCode'];
                          $enrolleeMotherName = $_POST['enrolleeMotherName'];
                          $enrolleeFatherName = $_POST['enrolleeFatherName'];
                          $enrolleeMotherPhone = $_POST['enrolleeMotherPhone'];
                          $enrolleeFatherPhone = $_POST['enrolleeFatherPhone'];
                          $motherOtherContacts =  $_POST['motherOtherContacts'];
                          $fatherOtherContacts = $_POST['fatherOtherContacts'];
                          $enrolleeGuardian = $_POST['enrolleeGuardian'];
                          $enrolleeSchoolServiceName = $_POST['enrolleeSchoolServiceName'];
                          $servicePlateNumber = $_POST['servicePlateNumber']; 
                          $servicePhoneNumber = $_POST['servicePhoneNumber'];
                          $enrolleePSANo = $_POST['enrolleePSANo'];
                          $enrolleeLRN =  $_POST['enrolleeLRN'];
                          //$enrolleeCode = $_POST['enrolleeCode'];
                          $enrolleeRefNo = "Unknown";
                          $enrolleeNSO = "Unknown";
                          $enrollee137 = "Unknown";
                          $enrollee138 = "Unknown";
                          $enrolleeGMC ="Unknown";


                           ob_start();
                      require('../includes/fpdf17/fpdf.php');

                      $pdf = new FPDF();
                      $pdf->AddPage();
                      //set font to arial, bold, 14pt
                        $pdf->SetFont('Arial','B',12);

                        //Cell(width , height , text , border , end line , [align] )

                        $pdf->Cell(120 ,5,'Lucban Christian School',0,0);
                        $pdf->Cell(59 ,5,'Enrollment Confirmation',0,1);//end of line

                        //set font to arial, regular, 12pt
                        $pdf->SetFont('Arial','',10);

                        $pdf->Cell(120 ,5,'Lucban - Luisiana Rd, Brgy Abang',0,0);
                        $pdf->Cell(59 ,5,'',0,1);//end of line
                        

                        $pdf->Cell(120 ,5,'Lucban Quezon, 4328 ',0,0);
                        $pdf->Cell(25 ,5,'Date',0,0);
                        $pdf->Cell(34 ,5,$enrolledWhen,0,1);//end of line

                         
                        $pdf->Cell(120 ,5,'Phone [(042) 540 3113]',0,0);
                        $pdf->Cell(25,5,'Student ID: ',0,0);
                        $pdf->Cell(34, 5, $studentID, 0, 1);//end of line
                        
                        

                        //make a dummy empty cell as a vertical spacer
                        $pdf->Cell(189 ,10,'',0,1);//end of line


                        $pdf->SetFont('Arial','B',12);
                        $pdf->Cell(192 ,5,'Student Information',1,1,'C');

                        //billing address
                        $pdf->SetFont('Arial','',10);
                        

                        //add dummy cell at beginning of each line for indentation
                        
                        $pdf->Cell(192 ,5,'[LAST NAME: ]   '.$enrolleeLastName.'                    [FIRST NAME: ]   '.$enrolleeFirstName.'                   [MIDDLE NAME: ]   '.$enrolleeMiddleName,1,1);

                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->Cell(30 ,5,'Gender:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeGender,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Grade Level:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$gradeLevel,1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Age:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeAge,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,'',1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Birthday:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeBirthday,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,'',1,1);


                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Birth Place:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeBirthPlace,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,'',1,1);

                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(192 ,5,'Home Address',1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->Cell(30 ,5,'House Number:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeHouseNo,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Street:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$enrolleeStreet,1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Barangay:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeBarangay,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'City/Municipality:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$enrolleeMunicipality,1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Province:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeProvince,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Country:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$enrolleeCountry.', '.$enrolleeZipCode,1,1);


                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(192 ,5,'Home Address',1,1);


                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Mothers Name:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeMotherName,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Fathers Name:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$enrolleeFatherName,1,1);



                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Mothers Phone#:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeMotherPhone,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Fathers Phone#:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(62 ,5,$enrolleeFatherPhone,1,1);

                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(35 ,5,'Mothers W-Phone#:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(55 ,5,$motherOtherContacts,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(35 ,5,'Fathers W-Phone#:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(57 ,5, $fatherOtherContacts,1,1);


                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(50 ,5,'Guardian/s:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(142 ,5,$enrolleeGuardian,1,1);



                        $pdf->SetFont('Arial','B',10);

                        $pdf->Cell(192 ,5,'',1,1);
                        $pdf->Cell(192 ,5,'School Service Information',1,1);


                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(40 ,5,'School Service Name:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(60 ,5,$enrolleeSchoolServiceName,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(30 ,5,'Plate Number:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(52 ,5, $servicePlateNumber,1,1);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->Cell(80 ,5,'Services Phone Number:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(102 ,5, $servicePhoneNumber,1,1);



                        $pdf->SetFont('Arial','B',10);

                        $pdf->Cell(192 ,5,'',1,1);
                        $pdf->Cell(192 ,5,'Files and Documents',1,1);


                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(50 ,5,'PSA Birth Certificate Number:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(36 ,5,$enrolleePSANo,1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(60 ,5,'Learners Reference Number (LRN):',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(36 ,5, $enrolleeLRN,1,1);


                        $pdf->Cell(10 ,5,'',0,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(40 ,5,'NSO Birth Certificate:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(8 ,5,'[  ]',1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(35 ,5,'Form 137:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(8 ,5, '[  ]',1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(35 ,5,'Form 138:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(8 ,5,'[  ]',1,0);
                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(40 ,5,'Good Moral Character:',1,0);
                        $pdf->SetFont('Arial','',10);
                        $pdf->Cell(8 ,5, '[  ]',1,1);



                        $pdf->SetFont('Arial','',10);

                        $pdf->Cell(192 ,5,'',0,1);
                        $pdf->Cell(192 ,5,'',0,1);
                        $pdf->Cell(192 ,5,'I have read this school policy, understood and agreed to the terms stated in the online application.',0,1);


                        $pdf->Cell(192 ,5,'',0,1);
                        $pdf->Cell(60 ,5,'',0,0);
                        $pdf->Cell(60 ,5,'',0,0);
                        $pdf->Cell(72 ,5,$enrolledBy,0,1,'C');
                        $pdf->Cell(60 ,5,'',0,0);
                        $pdf->Cell(60 ,5,'',0,0);
                        $pdf->Cell(72 ,5,'Signature Over Printed Name',0,1,'C');



                        //make a dummy empty cell as a vertical spacer
                        $pdf->Cell(189 ,10,'',0,1);//end of line

                        //invoice contents
                        $pdf->SetFont('Arial','B',12);
                        $pdf->Cell(192 ,5,'Student Assesment',1,1,'C');

                        $pdf->SetFont('Arial','B',10);
                        $pdf->Cell(120 ,5,'Description',1,0);
                        $pdf->Cell(38 ,5,'Taxable',1,0);
                        $pdf->Cell(34 ,5,'Amount',1,1);//end of line

                        $pdf->SetFont('Arial','',10);

                        //Numbers are right-aligned so we give 'R' after new line parameter
                        $pdf->Cell(120 ,5,'Tuition Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$tuitionFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'Miscellaneous Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$miscellaneousFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'Book Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5, $booksFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'Other Instructional Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5, $otherInstructionalFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'Uniform Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$uniformsFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'Registration Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$registrationFee,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'PTA Donation Fee',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$ptaDonationFee,1,1,'R');//end of line


                        $pdf->Cell(120 ,5,'Other Fees',1,0);
                        $pdf->Cell(38 ,5,'-',1,0);
                        $pdf->Cell(34 ,5,$otherFee,1,1,'R');//end of line

                        //summary
                        $pdf->Cell(120 ,5,'',0,0);
                        $pdf->Cell(38 ,5,'Subtotal',0,0);
                        $pdf->Cell(10 ,5,'Php',1,0);
                        $pdf->Cell(24 ,5,$totalFees,1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'',0,0);
                        $pdf->Cell(38 ,5,'Taxable',0,0);
                        $pdf->Cell(10 ,5,'Php',1,0);
                        $pdf->Cell(24 ,5,'0',1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'',0,0);
                        $pdf->Cell(38 ,5,'Tax Rate',0,0);
                        $pdf->Cell(10 ,5,'Php',1,0);
                        $pdf->Cell(24 ,5,'',1,1,'R');//end of line

                        $pdf->Cell(120 ,5,'',0,0);
                        $pdf->Cell(38 ,5,'Total Assessment Fee',0,0);
                        $pdf->Cell(10 ,5,'Php',1,0);
                        $pdf->Cell(24 ,5,$totalFees,1,1,'R');//end of line

                        $pdf->Cell(192 ,5,'',0,1);
                      
                      
                        $pdf->Cell(72 ,5,'Acknowledged by:',0,1,'C');
                        $pdf->Output();
                        ob_end_flush(); 

  




                            //echo '<script type = "text/javascript"> alert("Error updating record.");</script>';

    }
?>
