<?php

include_once '../resource/db.php';
include_once '../resource/session.php';

$deleteAnnouncement = $_GET['id'];

$con = new mysqli('localhost', 'root', 'Dont4GET', 'lcs');    
    
$sql = $con-> query("DELETE FROM announcement WHERE id='$deleteAnnouncement'");
header("Location: ../admin/add-announcements.php");

?>