<?php


$con = 'mysql:host=localhost; dbname=lcs';
$username= 'root';
$password = 'Dont4GET';

try{

	$dbconn = new PDO ($con, $username, $password);

}catch (PDOException $ex){
	echo "Database connection failed. ".$ex->getMessage();
}


